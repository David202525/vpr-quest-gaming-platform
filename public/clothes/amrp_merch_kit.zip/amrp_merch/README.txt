Худи AMRP (женское), 10 цветов: a-j
1. Durty Cloth Tool -> New project
2. Add female -> выбрать jbib_000_u.ydd
3. Add textures -> выбрать все jbib_diff_000_*_uni.ytd
4. Build -> имя amrp_merch -> FiveM/Singleplayer
5. Папку amrp_merch скопировать в client_packages\game_resources\dlcpacks\
6. Перезапустить сервер, в игре /clothedit
