Мужские вещи: jbib_000_u.ydd, jbib_diff_000_a_uni.ytd и т.д. Подробно — names.txt
