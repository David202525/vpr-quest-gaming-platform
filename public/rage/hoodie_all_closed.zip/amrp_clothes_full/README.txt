ВСЕ ЖЕНСКИЕ ХУДИ БЕЗ ВЫРЕЗА НА ГРУДИ — ПАК amrp_clothes

Во всех 4 моделях вырез закрыт (как в худи AMRP, которая уже работает).
  jbib_000 — худи AMRP, 18 цветов (a…r)
  jbib_001 — «Зимняя коллекция», 6 цветов
  jbib_002 — «Новогодняя коллекция», 6 цветов
  jbib_003 — «Арт», 6 цветов

ЧТОБЫ НИЧЕГО НЕ СЛОМАТЬ
0. Скопируйте текущий dlcpacks\amrp_clothes\dlc.rpf в запасную папку (например C:\amrp_backup).
   Если что-то пойдёт не так — просто верните его обратно.

СБОРКА (папка НЕ на рабочем столе/OneDrive, например C:\amrp_mods\amrp_clothes_full)
1. grzyClothTool: File → New Project.
2. Add → Female → jbib_000_u.ydd. Проверьте: 18 цветов.
3. Add → Female → jbib_001_u.ydd, затем jbib_002_u.ydd, затем jbib_003_u.ydd —
   строго по порядку, тогда номера худи не собьются. У каждой должно быть 6 цветов.
4. Build → имя amrp_clothes, Singleplayer → замените dlc.rpf в dlcpacks\amrp_clothes.
5. Перезапустите сервер. В консоли должно быть:  [dlc] amrp_clothes: OK — одежда: ♀jbib 4
6. Себе и игрокам — удалить RAGEMP/client_resources и перезайти.
7. /clothedit → у каждой из 4 худи «Майка под верхом» = -1 → Сохранить.
