ПАК МАШИН amrp_cars — ШАБЛОН ПОД ВАШИ МОДЕЛИ

Внутри уже готовы все настройки на 3 машины:
  amrpcar1 — седан (задний привод, ~220 км/ч, звук Tailgater)
  amrpcar2 — спорткар (задний привод, ~265 км/ч, звук Elegy)
  amrpcar3 — внедорожник (полный привод, ~230 км/ч, звук Baller)

КАК ПОДСТАВИТЬ СВОЮ МАШИНУ
1. Возьмите модель, например m5f90.yft, m5f90_hi.yft, m5f90.ytd.
2. Во всех 4 файлах в common/data замените amrpcar1 на m5f90 (Ctrl+H в Notepad++,
   «Заменить все», регистр не учитывать — заменится и AMRPCAR1 в handling).
3. Положите 3 файла модели в x64/vehicles.rpf/.
Нужно меньше машин — удалите лишний блок <Item>...</Item> во всех 4 файлах.
Нужно больше — скопируйте блок и поменяйте имя (в carvariations и carcols поменяйте
ещё номер набора тюнинга 1300/1301/1302 на следующий свободный, например 1303).

КАК СОБРАТЬ В OpenIV
1. OpenIV → Tools → New → RPF7 Archive, назовите dlc.rpf (Encryption: OPEN).
2. Перенесите внутрь content.xml, setup2.xml и папку common целиком.
3. Внутри dlc.rpf создайте папку x64, в ней New → RPF7 Archive «vehicles.rpf»
   и перетащите туда .yft/.ytd.
4. Готовый dlc.rpf положите на сервер: client_packages/game_resources/dlcpacks/amrp_cars/dlc.rpf
5. Перезапустите сервер — проверка [dlc] в консоли должна показать «amrp_cars: OK».
6. В игре: /adddlc m5f90 BMW M5 F90 — машина появится в списке DLC админки.

ЧТО МОЖНО КРУТИТЬ (handling.meta)
  fInitialDriveForce — мощность (0.30 обычная, 0.40 очень быстрая)
  fInitialDriveMaxFlatVel — макс. скорость (км/ч ≈ значение × 1.32)
  fDriveBiasFront — привод: 0.0 задний, 0.5 полный, 1.0 передний
  fTractionCurveMax / Min — сцепление (2.4–2.8)
  fBrakeForce — тормоза (0.8–1.2)
  fMass — масса, кг
Звук: в vehicles.meta тег <audioNameHash> — имя любой машины GTA (ADDER, ZENTORNO, SULTAN и т.д.).
