ЖЕНСКАЯ ХУДИ AMRP — ОТДЕЛЬНЫЙ ПАК amrp_hoodie_f

В папке female: модель jbib_000_u.ydd и 18 цветов (a–r).
Все файлы проверены, они целые.

1. УБЕРИТЕ СТАРОЕ
   Из client_packages/game_resources/dlcpacks удалите папки
   amrp_clothes и amrp_merch (если есть).
   Игрокам и себе: удалить папку RAGEMP/client_resources.

2. СОБЕРИТЕ ПАК В grzyClothTool
   - File → New Project (обязательно НОВЫЙ, старый проект не открывать).
   - Add → Female → выберите jbib_000_u.ydd из папки female.
   - Проверьте, что подтянулись 18 цветов и модель видна в 3D-превью.
   - BUILD: Name = amrp_hoodie_f, формат = Singleplayer.
   - Должна получиться папка amrp_hoodie_f с файлом dlc.rpf внутри.

3. ПОЛОЖИТЕ НА СЕРВЕР
   client_packages/game_resources/dlcpacks/amrp_hoodie_f/dlc.rpf
   Только dlc.rpf — никаких fxmanifest.lua, .meta и папки stream рядом.

4. ПРОВЕРКА
   В консоли сервера: [dlc] amrp_hoodie_f: OK — одежда: ♀jbib 1
   В игре: /clothedit → худи → листайте цвета, их должно быть 18.

Следующие вещи (рюкзак, штаны и т.д.) собирайте так же — каждую
своим паком со своим именем: amrp_backpack, amrp_pants и т.п.
