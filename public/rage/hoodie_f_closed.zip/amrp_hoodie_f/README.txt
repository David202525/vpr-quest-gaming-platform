ЖЕНСКАЯ ХУДИ AMRP — БЕЗ ВЫРЕЗА НА ГРУДИ

Модель jbib_000_u.ydd исправлена: V-вырез закрыт, ворот круглый.
Майка под худи больше не нужна — в редакторе ставьте «Майка под верхом» = -1.

1. В grzyClothTool: File → New Project → Add → Female → jbib_000_u.ydd из этой папки.
   Цветов должно быть 18 (a–r).
2. BUILD: Name = amrp_hoodie_f, формат = Singleplayer.
3. Замените client_packages/game_resources/dlcpacks/amrp_hoodie_f/dlc.rpf новым.
4. Себе и игрокам удалить папку RAGEMP/client_resources, перезапустить сервер.
5. /clothedit → худи → Майка под верхом = -1, Руки/торс подобрать (обычно 3, 4 или 7) → Сохранить.
