ХУДИ AMRP (С НАДПИСЯМИ) — БЕЗ ВЫРЕЗА НА ГРУДИ

Это та же первая худи с логотипами AMRP, 10 цветов (a–j).
Вырез на груди закрыт, ворот круглый. Майка не нужна: «Майка под верхом» = -1.

1. grzyClothTool: File → New Project → Add → Female → jbib_000_u.ydd из этой папки.
   Должно быть 10 цветов.
2. BUILD: Name = amrp_hoodie_f, Singleplayer.
3. Замените dlcpacks/amrp_hoodie_f/dlc.rpf, удалите RAGEMP/client_resources, перезапустите сервер.
4. /clothedit → худи → Майка под верхом = -1 → Сохранить.
