ВСЕ ЖЕНСКИЕ ХУДИ БЕЗ ВЫРЕЗА — ПАК amrp_hoodie_f

  jbib_000 — худи AMRP (та, что уже работает), 18 цветов: a…j с надписями AMRP + k…r новые
  jbib_001 — «Зимняя коллекция», 6 цветов
  jbib_002 — «Новогодняя коллекция», 6 цветов
  jbib_003 — «Арт», 6 цветов
Во всех моделях вырез закрыт.

ЧТОБЫ НЕ СЛОМАТЬ
0. Скопируйте текущий dlcpacks\amrp_hoodie_f\dlc.rpf в C:\amrp_backup.
   Если что-то не так — верните его обратно.

СБОРКА (папка вне рабочего стола/OneDrive, например C:\amrp_mods\amrp_hoodie_f)
1. grzyClothTool: File → New Project.
2. Add → Female → jbib_000_u.ydd ПЕРВОЙ. Проверьте: 18 цветов.
3. Затем Add → Female по порядку: jbib_001_u.ydd, jbib_002_u.ydd, jbib_003_u.ydd (по 6 цветов).
4. Build → имя amrp_hoodie_f, Singleplayer → замените dlc.rpf в dlcpacks\amrp_hoodie_f.
5. Перезапуск сервера. В консоли:  [dlc] amrp_hoodie_f: OK — одежда: ♀jbib 4
6. Удалить RAGEMP/client_resources, перезайти.
7. /clothedit → у новых худи «Майка под верхом» = -1 → Сохранить.
