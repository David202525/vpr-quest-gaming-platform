const db = require('./database');
global.db = db;

function load(file) {
    try { require(file); return true; } catch (e) { console.log('[CORE] ' + file + ': ' + e.message); return false; }
}

load('./modules/logs.js');
load('./modules/admin.js');
load('./modules/help.js');
load('./modules/hud.js');
load('./modules/ui.js');
load('./modules/intro.js');
load('./modules/wanted.js');
load('./modules/spawn.js');
load('./modules/houses.js');
load('./modules/phone.js');
load('./modules/gov.js');
load('./modules/voice.js');

const core = ['vehicles', 'auth', 'creator'].filter(function (n) { return load('./modules/' + n + '.js'); });
console.log('[CORE] Modules loaded: ' + core.join(', ') + '.');
